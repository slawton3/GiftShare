from django.contrib import admin
from .models import GLUser, Gift

admin.site.register(GLUser)
admin.site.register(Gift)